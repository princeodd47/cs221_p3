This zip file contains the following files:

ReadMe.txt - The file you are currently reading.

Prog3.txt - This is actually a demonstration executable file of program 3.  To run
	the program change the ".txt" extension to ".exe".  You should run the
	application from a DOS prompt window.

BookData.txt - A data file which you can used for this programming assignment. The
	book information in this file is arranged so that the standard insert function
	in a binary tree will result in a tree that is as close to being balanced as
	possible.

SprintReport_P3.docx - Scrum report for sprints 1 and 2 for this assignment.  Fill
	this in and return it with your source code.